# multireso
Multi screen resolutions checker。いわゆる卒研の進捗
